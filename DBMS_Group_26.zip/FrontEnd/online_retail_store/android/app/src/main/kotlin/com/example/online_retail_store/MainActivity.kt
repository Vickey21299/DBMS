package com.example.online_retail_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
