# DBMS Project

- An Online Retails System!
- Built using Python and Flutter
- Backend is Flask APIs returning data from a MySQL Database connected via mysql-connector
- Frontend is a cross-platform application built using Flutter