Create database RetailDB;
Use RetailDB;