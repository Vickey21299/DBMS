Use RetailDB;
create table user (
	id INT NOT NULL AUTO_INCREMENT,
	Address VARCHAR(50) NOT NULL,
	Name VARCHAR(50) NOT NULL,
	EmailID VARCHAR(50) NOT NULL UNIQUE,
	Password VARCHAR(50) NOT NULL,
	PhoneNumber VARCHAR(50) NOT NULL,
	PRIMARY KEY (id)
);
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (1, '827 Pearson Pass', 'Kerwinn Libby', 'klibby0@webeden.co.uk', 'iYRXekK', '1863621343');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (2, '37 Lindbergh Park', 'Annetta Stanislaw', 'astanislaw1@sun.com', 'cKQNRxJguFR', '9896569130');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (3, '467 Roxbury Hill', 'Nathan McCrory', 'nmccrory2@newsvine.com', 'IFdaKdsQzgI', '2258449848');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (4, '7 Novick Park', 'Amerigo Polamontayne', 'apolamontayne3@admin.ch', 'w9XskuJ', '5095944974');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (5, '6856 Ridgeview Place', 'Heath Curdell', 'hcurdell4@google.com.au', 'ZbaCjGm8X', '7037490329');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (6, '6 Kings Center', 'Gerri Straker', 'gstraker5@marketwatch.com', '63OdqXX', '8137631753');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (7, '1231 Northridge Plaza', 'Sileas Braz', 'sbraz6@hud.gov', 'sVEZ5RqJj3r', '7503701488');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (8, '821 Muir Road', 'Rochell Ivasyushkin', 'rivasyushkin7@i2i.jp', 'tznJd2k6', '9836607797');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (9, '701 Little Fleur Crossing', 'Olivia Caistor', 'ocaistor8@dailymail.co.uk', 'XhD9T8FGEQ', '5809372849');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (10, '335 Transport Circle', 'Florella Edgerton', 'fedgerton9@umich.edu', 'Yq3nMQpZsMwA', '8426489472');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (11, '4421 Summerview Point', 'Deborah Benasik', 'dbenasika@cdbaby.com', '1zWt73', '6199848047');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (12, '1 Tennessee Junction', 'Durand Myers', 'dmyersb@ebay.co.uk', 'PVaRlHrrqk', '1165440484');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (13, '01642 Lyons Alley', 'Jemimah Petrina', 'jpetrinac@fastcompany.com', 'HuCcUxo', '5092726302');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (14, '2 Texas Way', 'Blanch Hasted', 'bhastedd@woothemes.com', 'iJttzA6k', '7585215612');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (15, '137 Portage Lane', 'Cleve Pasfield', 'cpasfielde@hibu.com', '8XzCqAUhF4', '4461868722');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (16, '18 Briar Crest Junction', 'Duke Bagshawe', 'dbagshawef@geocities.jp', 'Wo076m4I', '3889661378');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (17, '2 Brown Way', 'Lela Bessom', 'lbessomg@virginia.edu', 'ilmAD10D', '8572740956');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (18, '52 Merrick Drive', 'Ody Dann', 'odannh@archive.org', '3qQJOpWmYxy', '2083594521');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (19, '4057 Bowman Park', 'Haslett Brandenberg', 'hbrandenbergi@mac.com', 'wkTB2XD7GQR', '1172140750');
insert into user (id, Address, Name, EmailID, Password, PhoneNumber) values (20, '5086 Fuller Terrace', 'Anastassia Whiteside', 'awhitesidej@youtu.be', '8TbbqpzA', '2848944007');
